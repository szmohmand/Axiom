#!/bin/sh
set -eu
export DEMO_MODE=1
export AUTO_PAPER=1
uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
