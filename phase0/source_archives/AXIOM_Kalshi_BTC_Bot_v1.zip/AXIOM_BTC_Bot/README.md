# AXIOM — BTC 15-Minute Research & Paper-Trading Bot

**This is a runnable application, not a code downloader.** It has its own browser dashboard, a 15-second read-only market-data loop, independent experimental probability calculations, BTC spot momentum research signals, automated **paper** entries, a SQLite ledger, and official Kalshi result grading. It never authenticates to Kalshi or places real orders.

## Quick start

Requirements: Python 3.10+ and internet access for live public market feeds.

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
```

Open **http://127.0.0.1:8000**. From the iPhone/iPad, the easiest way to access it remotely is to host this project on a cloud web service with a persistent disk. `render.yaml` is included for a new Render deployment from **your own** GitHub repository. Do not deploy over an existing bot or service.

The app runs on startup. There are no separate training or download steps. When it first launches, allow a poll cycle for data to populate. The page refreshes itself every five seconds.

### Test the UI without network access

```bash
DEMO_MODE=1 uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
```

The UI prominently labels **DEMO / SYNTHETIC DATA**. Synthetic numbers are never presented as real trades or predictions. Set `DEMO_MODE=0` for public real-market reads.

### Optional manual paper entry and CSV export

Set `BOT_ADMIN_TOKEN` to your own long random value before starting. The UI's **Unlock manual** button prompts for this token (held only in browser memory). You can then record simulated YES/NO positions at the last published ask, one per market, and download CSV data. Without a token, manual writes and exports remain disabled. The bot can still auto-paper trade when a model-market discrepancy passes the conservative research gate.

### Deploy from your iPad

This package contains a Render Blueprint (`render.yaml`) that provisions a new starter web service and persistent 1 GB disk. Its `BOT_ADMIN_TOKEN` is generated at deployment. You must first upload this code to your own new GitHub repository through a connected coding workflow; this ZIP is **not** already deployed and cannot make a live public URL by itself. Do not publish API keys or personal credentials. Render may charge for the service/disk.

## How it works

| Stage | Details |
|---|---|
| Contract discovery | Polls public Kalshi `KXBTC15M` open markets; uses `floor_strike` **only when published** |
| BTC feed | Coinbase Exchange ticker and 1-minute OHLCV candles; spot is a **proxy**, not the CF Benchmarks BRTI settlement index |
| Forecast | Transparent GBM-inspired volatility distribution using 1-minute realized volatility and capped recent drift; **not trained/calibrated and not known to beat Kalshi** |
| Confidence gate | Records the **first** ABOVE/BELOW call only when an experimental model stays ≥85% on a single side across at least 10 seconds of fresh observations; never rewrites that first call |
| Contract opportunity | Compares experimental outcome probability to observed YES/NO ask; signals only when **gross estimated discrepancy ≥8 percentage points**, ask is 5–92¢, and ≥90 seconds remain |
| Automatic paper entries | Default enabled (`AUTO_PAPER=1`), **one synthetic entry per market at the displayed ask**, no fees/slippage, no actual order submitted |
| Spot scalping lens | Separate EMA(9/21) + ATR(14) research LONG/SHORT/WAIT, indicative entry/stop/target; no spot execution or realized scalp backtest |
| Settlement | Fetches market-specific official Kalshi result (`yes`/`no`) once `settled` / `finalized`; never substitutes Coinbase price for official settlement |
| Journal | SQLite first calls, paper entries, latest market observations, aggregate statistics; three CSV exports with admin token |

**What this bot does not do**: live trades, guaranteed fills, calibrated probabilities, verified historical accuracy, a robust Kalshi fee model, official intrawindow BRTI data, actual scalp position tracking, downloaded source from 17 different projects, or exact reproduction of any private commercial bot. Those are not implied by the dashboard.

## Configuration

Set these environment variables (see `.env.example`):

- `DEMO_MODE=0` — set `1` to use synthetic offline feeds
- `AUTO_PAPER=1` — set `0` to disable automatic simulated entries
- `POLL_SECONDS=15` — price/market polling interval; one process only
- `BOT_ADMIN_TOKEN=...` — optional long random secret for manual paper and CSV exports
- `DATA_PATH=./data/bot.sqlite3` — persistence path; needs persistent storage in cloud

**Cloud operational note:** Run exactly **one** server worker and one service instance against each SQLite database. A free/non-persistent file system may erase the ledger on restart. The included Render blueprint requests a persistent disk. For real research, audit exchange fees and snapshot execution assumptions, and validate market close/settlement behavior with live samples before interpreting results.

## API

- `GET /` — mobile-friendly dashboard
- `GET /health` — read-only health
- `GET /api/state` — current contract, model, signals, history, errors
- `POST /api/paper` — paper entry; requires Bearer admin token
- `GET /api/export/{first_calls|paper_trades|observations}` — CSV, requires admin token

## Tests

```bash
pip install pytest httpx
pytest -q
```

Includes unit tests for market parsing, invalid/missing strikes, coherent probabilities, profit calculation, continuous-threshold gating, immutable first calls, persistent ledger, official-result grading, and offline HTTP integration.

## Public references and provenance

- [Kalshi BTC 15-minute market mechanics and BRTI settlement explanation](https://kalshieye.com/guides/kalshi-15-minute-crypto-markets/)
- [Kalshi open market / quote endpoints](https://external-api.kalshi.com/trade-api/v2/markets?series_ticker=KXBTC15M&status=open)
- [Coinbase Exchange public market candles](https://docs.cdp.coinbase.com/exchange/reference/exchangerestapi_getproductcandles)
- [Kalshi market-data API overview](https://docs.kalshi.com/)
- Original research reports supplied by user: *Digital-forensics investigation: Kalshi Bitcoin 15-minute bot shown in the screenshots* and *The Search for the World's Most Accurate Kalshi Trading Bot*.

This code was **written anew for this project** based on the public market-data model and published high-level research patterns. It is not the original source of TerryCalls, Patient Predator MAX, Kalshi Sniper, jaldrich2023, or any other proprietary/researched third-party system.

## License

The original code in this package is offered under MIT terms (see `LICENSE`). External trademarks, data, provider terms, and third-party code are unaffected.
