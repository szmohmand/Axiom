"""SQLite event journal. One worker per database (set WEB_CONCURRENCY=1)."""
import sqlite3
import threading
import time
import os
from pathlib import Path
from .engine import paper_result

class Ledger:
    def __init__(self, location):
        Path(location).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(location, check_same_thread=False, timeout=15)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('PRAGMA busy_timeout=10000')
        with self.lock:
            self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS watches(
              ticker TEXT PRIMARY KEY, side TEXT, since REAL, last_seen REAL);
            CREATE TABLE IF NOT EXISTS first_calls(
              ticker TEXT PRIMARY KEY, side TEXT NOT NULL, probability REAL NOT NULL,
              created REAL NOT NULL, seconds_left INTEGER NOT NULL, spot REAL,
              target REAL, result TEXT, graded REAL);
            CREATE TABLE IF NOT EXISTS paper_trades(
              id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT NOT NULL UNIQUE,
              side TEXT NOT NULL, entry REAL NOT NULL, created REAL NOT NULL,
              seconds_left INTEGER NOT NULL, model_prob REAL,
              source TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'OPEN',
              result TEXT, pnl REAL, graded REAL);
            CREATE TABLE IF NOT EXISTS observations(
              id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, ts REAL NOT NULL,
              spot REAL, target REAL, market_prob REAL, model_prob REAL,
              signal TEXT);
            CREATE INDEX IF NOT EXISTS ix_obs_ts ON observations(ts);
            ''')
            self.conn.commit()
    def first_call(self, market, model, spot, now, hold_seconds=10, poll_gap=40):
        """Lock first directional 85%-confidence call after continuous observations."""
        ticker=market['ticker']; p=model.get('prob_above'); side=None
        if model.get('available') and p is not None and market['seconds_left']>0:
            if p >= .85: side='ABOVE'
            elif p <= .15: side='BELOW'
        with self.lock:
            if self.conn.execute('SELECT 1 FROM first_calls WHERE ticker=?', (ticker,)).fetchone():
                return None
            prev=self.conn.execute('SELECT * FROM watches WHERE ticker=?', (ticker,)).fetchone()
            if side is None:
                self.conn.execute('DELETE FROM watches WHERE ticker=?', (ticker,))
                self.conn.commit(); return None
            if not prev or prev['side'] != side or now-prev['last_seen'] > poll_gap:
                self.conn.execute('INSERT OR REPLACE INTO watches VALUES (?,?,?,?)', (ticker,side,now,now))
                self.conn.commit(); return None
            self.conn.execute('UPDATE watches SET last_seen=? WHERE ticker=?',(now,ticker))
            if now-prev['since'] >= hold_seconds:
                self.conn.execute('''INSERT INTO first_calls(ticker,side,probability,created,seconds_left,spot,target)
                  VALUES(?,?,?,?,?,?,?)''', (ticker,side, p if side=='ABOVE' else 1-p,now,
                      market['seconds_left'],spot,market.get('target')))
                self.conn.execute('DELETE FROM watches WHERE ticker=?',(ticker,))
                self.conn.commit()
                return {'ticker':ticker,'side':side,'probability':p if side=='ABOVE' else 1-p}
            self.conn.commit(); return None
    def watch_info(self, ticker):
        with self.lock:
            r=self.conn.execute('SELECT * FROM watches WHERE ticker=?',(ticker,)).fetchone()
            if r: return {'side':r['side'],'held_seconds':max(0,round(time.time()-r['since']))}
            return None
    def observed(self, market, model, spot, now):
        with self.lock:
            self.conn.execute('''INSERT INTO observations(ticker,ts,spot,target,market_prob,model_prob,signal)
                VALUES(?,?,?,?,?,?,?)''',(market['ticker'], now, spot, market.get('target'),
                market.get('market_mid'),model.get('prob_above'),model.get('side')))
            self.conn.execute('DELETE FROM observations WHERE id NOT IN (SELECT id FROM observations ORDER BY id DESC LIMIT 7000)')
            self.conn.commit()
    def trade(self, market, side, now, model_probability=None, source='MANUAL'):
        side=side.upper()
        if side not in ('YES','NO'): raise ValueError('Side must be YES or NO')
        if market['seconds_left'] < 45: raise ValueError('Market too close to close')
        entry=market.get('yes_ask' if side=='YES' else 'no_ask')
        if entry is None or not .01<=entry<=.99: raise ValueError('No valid current ask available')
        with self.lock:
            try:
                c=self.conn.execute('''INSERT INTO paper_trades(ticker,side,entry,created,seconds_left,model_prob,source)
                  VALUES(?,?,?,?,?,?,?)''', (market['ticker'],side,entry,now,market['seconds_left'],
                          model_probability,source))
                self.conn.commit()
                return {'id':c.lastrowid,'ticker':market['ticker'],'side':side,'entry':entry,'status':'OPEN'}
            except sqlite3.IntegrityError:
                raise ValueError('A paper position already exists for this market')
    def unresolved(self, max_rows=30):
        with self.lock:
            cur=self.conn.execute('''SELECT ticker FROM first_calls WHERE result IS NULL
              UNION SELECT ticker FROM paper_trades WHERE result IS NULL LIMIT ?''',(max_rows,))
            return [r['ticker'] for r in cur.fetchall()]
    def grade(self, ticker, result, now):
        if result not in ('yes','no'): raise ValueError('Requires Kalshi official yes/no')
        with self.lock:
            self.conn.execute('UPDATE first_calls SET result=?, graded=? WHERE ticker=? AND result IS NULL', (result, now, ticker))
            row=self.conn.execute('SELECT side,entry FROM paper_trades WHERE ticker=? AND result IS NULL',(ticker,)).fetchone()
            if row:
                pnl=paper_result(row['side'],row['entry'],result)
                self.conn.execute('''UPDATE paper_trades SET result=?,pnl=?,status='SETTLED',graded=?
                    WHERE ticker=? AND result IS NULL''',(result,pnl,now,ticker))
            self.conn.commit()
    def data(self, limit=60):
        with self.lock:
            calls=[dict(x) for x in self.conn.execute('SELECT * FROM first_calls ORDER BY created DESC LIMIT ?', (limit,))]
            trades=[dict(x) for x in self.conn.execute('SELECT * FROM paper_trades ORDER BY created DESC LIMIT ?', (limit,))]
            rows=self.conn.execute('SELECT side,result,probability FROM first_calls WHERE result IS NOT NULL').fetchall()
            completed=[dict(x) for x in self.conn.execute('SELECT pnl FROM paper_trades WHERE status="SETTLED"')]
            total=len(rows); correct=sum((x['side']=='ABOVE') == (x['result']=='yes') for x in rows)
            pcount=len(completed); wins=sum(x['pnl']>0 for x in completed); pnl=sum(x['pnl'] for x in completed)
            return {'calls':calls,'trades':trades,
                'stats':{'graded_calls':total,'correct_calls':correct,'first_call_accuracy':round(correct/total,4) if total else None,
                         'settled_paper_trades':pcount,'winning_paper_trades':wins,
                         'paper_win_rate':round(wins/pcount,4) if pcount else None,
                         'gross_paper_pnl':round(pnl,4), 'paper_fee_note':'Excludes trading fees and slippage; assumes ask fills'},
                'count':{'calls':self.conn.execute('SELECT count(*) FROM first_calls').fetchone()[0],
                         'paper':self.conn.execute('SELECT count(*) FROM paper_trades').fetchone()[0]}}
    def export(self, kind):
        if kind not in ('first_calls','paper_trades','observations'): raise ValueError('Invalid export')
        with self.lock:
            cur=self.conn.execute(f'SELECT * FROM {kind} ORDER BY id' if kind != 'first_calls' else 'SELECT * FROM first_calls ORDER BY created')
            return [x[0] for x in cur.description], [tuple(row) for row in cur.fetchall()]
