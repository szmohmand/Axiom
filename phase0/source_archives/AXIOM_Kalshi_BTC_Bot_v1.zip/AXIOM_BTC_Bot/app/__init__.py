"""BTC research bot package."""
