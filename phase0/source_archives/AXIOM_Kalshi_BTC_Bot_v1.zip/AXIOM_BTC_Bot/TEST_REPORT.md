# AXIOM v1.0 test report — November 15, 2026

- Python tests: **12 passed**, with synthetic fixtures and offline FastAPI HTTP integration.
- JavaScript: dashboard script passed `node --check` syntax validation.
- HTTP smoke test using an actual local `uvicorn` process in **DEMO_MODE**:
  - `GET /` → HTTP 200, dashboard HTML served.
  - `GET /api/state` → HTTP 200, demo market, spot, 62 one-minute candles and model available.
  - `POST /api/paper` (authorized) → HTTP 200, simulated YES entry recorded.
  - `GET /api/export/paper_trades` (authorized) → HTTP 200, CSV export returned.
- *Not tested*: actual external live Kalshi/Coinbase responses at runtime. This environment could not resolve external domains. This means live integration, network reliability, and real settlement grading still require live verification after deployment.
- *Not tested*: production browser visual render. The dashboard JavaScript passed syntax inspection and HTML delivered successfully, but local Chromium screenshot generation failed in this environment.
- *Not claimed*: improved prediction accuracy, profitability, real fills, fee-inclusive P&L, exchange-trading capability, or original code from third-party bots.
